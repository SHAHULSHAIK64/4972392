import java.util.Scanner;

class Task {
    String taskId, taskName, status;

    Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task{" + "ID='" + taskId + "', Name='" + taskName + "', Status='" + status + "'}";
    }
}

public class TaskManagementSystem {
    private class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
        }
    }

    private Node head;

    void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) temp = temp.next;
            temp.next = newNode;
        }
    }

    Task searchTask(String id) {
        Node temp = head;
        while (temp != null) {
            if (temp.task.taskId.equals(id)) return temp.task;
            temp = temp.next;
        }
        return null;
    }

    void deleteTask(String id) {
        if (head != null && head.task.taskId.equals(id)) {
            head = head.next;
            return;
        }
        Node temp = head;
        while (temp != null && temp.next != null) {
            if (temp.next.task.taskId.equals(id)) {
                temp.next = temp.next.next;
                return;
            }
            temp = temp.next;
        }
    }

    void traverseTasks() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.task);
            temp = temp.next;
        }
    }

    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Task\n2. Search Task\n3. Delete Task\n4. Traverse Tasks\n5. Exit");
            switch (scanner.nextInt()) {
                case 1:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Task ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Task Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Status: ");
                    String status = scanner.nextLine();
                    system.addTask(new Task(id, name, status));
                    break;
                case 2:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Task ID to search: ");
                    Task t = system.searchTask(scanner.nextLine());
                    System.out.println(t != null ? t : "Task not found.");
                    break;
                case 3:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Task ID to delete: ");
                    system.deleteTask(scanner.nextLine());
                    break;
                case 4:
                    system.traverseTasks();
                    break;
                case 5:
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
