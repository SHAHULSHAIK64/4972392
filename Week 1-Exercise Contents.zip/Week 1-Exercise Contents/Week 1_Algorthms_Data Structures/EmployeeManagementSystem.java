import java.util.Scanner;

class Employee {
    String employeeId, name, position;
    double salary;

    Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" + "ID='" + employeeId + "', Name='" + name + "', Position='" + position + "', Salary=" + salary + '}';
    }
}

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    void addEmployee(Employee employee) {
        if (size < employees.length) employees[size++] = employee;
    }

    Employee searchEmployee(String id) {
        for (Employee e : employees) if (e != null && e.employeeId.equals(id)) return e;
        return null;
    }

    void deleteEmployee(String id) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId.equals(id)) {
                System.arraycopy(employees, i + 1, employees, i, size - i - 1);
                employees[--size] = null;
                return;
            }
        }
    }

    void traverseEmployees() {
        for (Employee e : employees) if (e != null) System.out.println(e);
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(10);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Employee\n2. Search Employee\n3. Delete Employee\n4. Traverse Employees\n5. Exit");
            switch (scanner.nextInt()) {
                case 1:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Position: ");
                    String position = scanner.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = scanner.nextDouble();
                    system.addEmployee(new Employee(id, name, position, salary));
                    break;
                case 2:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter ID to search: ");
                    Employee e = system.searchEmployee(scanner.nextLine());
                    System.out.println(e != null ? e : "Employee not found.");
                    break;
                case 3:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter ID to delete: ");
                    system.deleteEmployee(scanner.nextLine());
                    break;
                case 4:
                    system.traverseEmployees();
                    break;
                case 5:
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
