class Computer {
    private String CPU, RAM, Storage;

    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.Storage = builder.Storage;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", Storage=" + Storage + "]";
    }

    static class Builder {
        private String CPU, RAM, Storage;

        Builder setCPU(String CPU) {
            this.CPU = CPU;
            return this;
        }

        Builder setRAM(String RAM) {
            this.RAM = RAM;
            return this;
        }

        Builder setStorage(String Storage) {
            this.Storage = Storage;
            return this;
        }

        Computer build() {
            return new Computer(this);
        }
    }
}

public class BuilderPatternExample {
    public static void main(String[] args) {
        Computer computer = new Computer.Builder()
                .setCPU("Intel i7")
                .setRAM("16GB")
                .setStorage("512GB SSD")
                .build();

        System.out.println(computer);
    }
}
