import java.util.Scanner;

public class ECommercePlatform {
    private Product[] products;
    private int size;

    public ECommercePlatform(int capacity) {
        this.products = new Product[capacity];
        this.size = 0;
    }

    public void addProduct(Product product) {
        if (size < products.length) {
            products[size++] = product;
        } else {
            System.out.println("Product list is full. Cannot add more products.");
        }
    }

    public Product linearSearch(String productName) {
        for (int i = 0; i < size; i++) {
            if (products[i].getProductName().equalsIgnoreCase(productName)) {
                return products[i];
            }
        }
        return null;
    }

    public Product binarySearch(String productName) {
        int left = 0, right = size - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(productName);
            if (comparison == 0) {
                return products[mid];
            }
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public void sortProductsByName() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (products[j].getProductName().compareToIgnoreCase(products[j + 1].getProductName()) > 0) {
                    Product temp = products[j];
                    products[j] = products[j + 1];
                    products[j + 1] = temp;
                }
            }
        }
    }

    public void displayProducts() {
        if (size == 0) {
            System.out.println("No products available.");
        } else {
            for (int i = 0; i < size; i++) {
                System.out.println(products[i]);
            }
        }
    }

    public static void main(String[] args) {
        ECommercePlatform platform = new ECommercePlatform(10);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nE-commerce Platform - Product Search");
            System.out.println("1. Add Product");
            System.out.println("2. Linear Search by Product Name");
            System.out.println("3. Binary Search by Product Name");
            System.out.println("4. Display Products");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    String productId = scanner.nextLine();
                    System.out.print("Enter Product Name: ");
                    String productName = scanner.nextLine();
                    System.out.print("Enter Category: ");
                    String category = scanner.nextLine();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    platform.addProduct(new Product(productId, productName, quantity, price));
                    break;

                case 2:
                    System.out.print("Enter Product Name to search (Linear): ");
                    String searchNameLinear = scanner.nextLine();
                    Product resultLinear = platform.linearSearch(searchNameLinear);
                    if (resultLinear != null) {
                        System.out.println("Product found: " + resultLinear);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;

                case 3:
                    platform.sortProductsByName();
                    System.out.print("Enter Product Name to search (Binary): ");
                    String searchNameBinary = scanner.nextLine();
                    Product resultBinary = platform.binarySearch(searchNameBinary);
                    if (resultBinary != null) {
                        System.out.println("Product found: " + resultBinary);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;

                case 4:
                    platform.displayProducts();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
