interface PaymentProcessor {
    void processPayment(double amount);
}

class PayPal {
    void makePayment(double amount) {
        System.out.println("Payment of $" + amount + " made using PayPal.");
    }
}

class CreditCard {
    void charge(double amount) {
        System.out.println("Charged $" + amount + " to Credit Card.");
    }
}

class PayPalAdapter implements PaymentProcessor {
    private PayPal payPal;

    PayPalAdapter(PayPal payPal) {
        this.payPal = payPal;
    }

    public void processPayment(double amount) {
        payPal.makePayment(amount);
    }
}

class CreditCardAdapter implements PaymentProcessor {
    private CreditCard creditCard;

    CreditCardAdapter(CreditCard creditCard) {
        this.creditCard = creditCard;
    }

    public void processPayment(double amount) {
        creditCard.charge(amount);
    }
}

public class AdapterPatternExample {
    public static void main(String[] args) {
        PaymentProcessor payPal = new PayPalAdapter(new PayPal());
        PaymentProcessor creditCard = new CreditCardAdapter(new CreditCard());

        payPal.processPayment(100.0);
        creditCard.processPayment(200.0);
    }
}
