// DependencyInjectionExample.java
interface CustomerRepository {
    String findCustomerById(int id);
}

class CustomerRepositoryImpl implements CustomerRepository {
    public String findCustomerById(int id) {
        return "Customer with ID: " + id;
    }
}

class CustomerService {
    private CustomerRepository repository;

    CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    void printCustomer(int id) {
        System.out.println(repository.findCustomerById(id));
    }
}

public class DependencyInjectionExample {
    public static void main(String[] args) {
        CustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);

        service.printCustomer(1);
    }
}
