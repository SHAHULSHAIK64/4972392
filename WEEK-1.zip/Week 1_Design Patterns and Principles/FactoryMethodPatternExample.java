interface Document {
    void create();
}

class WordDocument implements Document {
    public void create() {
        System.out.println("Creating Word Document");
    }
}

class PdfDocument implements Document {
    public void create() {
        System.out.println("Creating PDF Document");
    }
}

class ExcelDocument implements Document {
    public void create() {
        System.out.println("Creating Excel Document");
    }
}

abstract class DocumentFactory {
    abstract Document createDocument();
}

class WordFactory extends DocumentFactory {
    public Document createDocument() {
        return new WordDocument();
    }
}

class PdfFactory extends DocumentFactory {
    public Document createDocument() {
        return new PdfDocument();
    }
}

class ExcelFactory extends DocumentFactory {
    public Document createDocument() {
        return new ExcelDocument();
    }
}

public class FactoryMethodPatternExample {
    public static void main(String[] args) {
        DocumentFactory factory = new WordFactory();
        Document doc = factory.createDocument();
        doc.create();

        factory = new PdfFactory();
        doc = factory.createDocument();
        doc.create();

        factory = new ExcelFactory();
        doc = factory.createDocument();
        doc.create();
    }
}
