import java.util.Arrays;
import java.util.Scanner;

class Book {
    String bookId, title, author;

    Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book{" + "ID='" + bookId + "', Title='" + title + "', Author='" + author + "'}";
    }
}

public class LibraryManagementSystem {
    private Book[] books;
    private int size;

    LibraryManagementSystem(int capacity) {
        books = new Book[capacity];
        size = 0;
    }

    void addBook(Book book) {
        if (size < books.length) books[size++] = book;
    }

    void linearSearch(String title) {
        for (Book b : books) if (b != null && b.title.equalsIgnoreCase(title)) {
            System.out.println("Book found: " + b);
            return;
        }
        System.out.println("Book not found.");
    }

    void binarySearch(String title) {
        Arrays.sort(books, 0, size, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));
        int left = 0, right = size - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].title.compareToIgnoreCase(title);
            if (cmp == 0) {
                System.out.println("Book found: " + books[mid]);
                return;
            } else if (cmp < 0) left = mid + 1;
            else right = mid - 1;
        }
        System.out.println("Book not found.");
    }

    public static void main(String[] args) {
        LibraryManagementSystem system = new LibraryManagementSystem(10);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Book\n2. Search Book (Linear)\n3. Search Book (Binary)\n4. Exit");
            switch (scanner.nextInt()) {
                case 1:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Book ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Author: ");
                    String author = scanner.nextLine();
                    system.addBook(new Book(id, title, author));
                    break;
                case 2:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Title to search: ");
                    system.linearSearch(scanner.nextLine());
                    break;
                case 3:
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Title to search: ");
                    system.binarySearch(scanner.nextLine());
                    break;
                case 4:
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
