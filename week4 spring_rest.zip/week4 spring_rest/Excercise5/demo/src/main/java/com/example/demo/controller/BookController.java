package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookRepository bookRepository;

    // GET /books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookRepository.findAll();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BooksListRetrieved");
        return new ResponseEntity<>(books, headers, HttpStatus.OK);
    }

    // GET /books/{id}
    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK) // Default status for successful retrieval
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = bookRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookRetrieved");
        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }

    // POST /books
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // Default status for successful creation
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        Book savedBook = bookRepository.save(book);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/books/" + savedBook.getId()); // Location header for newly created resource
        return new ResponseEntity<>(savedBook, headers, HttpStatus.CREATED);
    }

    // PUT /books/{id}
    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK) // Default status for successful update
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) {
        if (!bookRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found");
        }
        book.setId(id);
        Book updatedBook = bookRepository.save(book);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookUpdated");
        return new ResponseEntity<>(updatedBook, headers, HttpStatus.OK);
    }

    // DELETE /books/{id}
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // Default status for successful deletion
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        if (!bookRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found");
        }
        bookRepository.deleteById(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookDeleted");
        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }
}

