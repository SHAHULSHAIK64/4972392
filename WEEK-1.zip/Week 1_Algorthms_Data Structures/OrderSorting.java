import java.util.Scanner;

class Order {
    private String orderId;
    private String customerName;
    private double totalPrice;

    public Order(String orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", totalPrice=" + totalPrice +
                '}';
    }
}

public class OrderSorting {
    private Order[] orders;
    private int size;

    public OrderSorting(int capacity) {
        this.orders = new Order[capacity];
        this.size = 0;
    }

    public void addOrder(Order order) {
        if (size < orders.length) {
            orders[size++] = order;
        } else {
            System.out.println("Order list is full. Cannot add more orders.");
        }
    }

    public void bubbleSort() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public void quickSort(int low, int high) {
        if (low < high) {
            int pi = partition(low, high);
            quickSort(low, pi - 1);
            quickSort(pi + 1, high);
        }
    }

    private int partition(int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() < pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public void displayOrders() {
        for (int i = 0; i < size; i++) {
            System.out.println(orders[i]);
        }
    }

    public static void main(String[] args) {
        OrderSorting orderSorting = new OrderSorting(10);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nE-commerce Platform - Order Sorting");
            System.out.println("1. Add Order");
            System.out.println("2. Sort Orders by Total Price (Bubble Sort)");
            System.out.println("3. Sort Orders by Total Price (Quick Sort)");
            System.out.println("4. Display Orders");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Order ID: ");
                    String orderId = scanner.nextLine();
                    System.out.print("Enter Customer Name: ");
                    String customerName = scanner.nextLine();
                    System.out.print("Enter Total Price: ");
                    double totalPrice = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    orderSorting.addOrder(new Order(orderId, customerName, totalPrice));
                    break;

                case 2:
                    orderSorting.bubbleSort();
                    System.out.println("Orders sorted using Bubble Sort.");
                    break;

                case 3:
                    orderSorting.quickSort(0, orderSorting.size - 1);
                    System.out.println("Orders sorted using Quick Sort.");
                    break;

                case 4:
                    orderSorting.displayOrders();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
