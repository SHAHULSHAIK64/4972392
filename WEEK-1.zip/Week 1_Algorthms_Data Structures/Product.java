//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

public class Product {
    private String productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(String productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters and Setters
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}

class InventoryManager {
    private Product[] inventory;
    private int size;

    public InventoryManager(int capacity) {
        this.inventory = new Product[capacity];
        this.size = 0;
    }

    public void addProduct(Product product) {
        if (size < inventory.length) {
            inventory[size++] = product;
        } else {
            System.out.println("Inventory is full. Cannot add more products.");
        }
    }

    public void updateProduct(String productId, Product newProductData) {
        for (int i = 0; i < size; i++) {
            if (inventory[i].getProductId().equals(productId)) {
                inventory[i] = newProductData;
                return;
            }
        }
        System.out.println("Product not found.");
    }

    public void deleteProduct(String productId) {
        for (int i = 0; i < size; i++) {
            if (inventory[i].getProductId().equals(productId)) {
                for (int j = i; j < size - 1; j++) {
                    inventory[j] = inventory[j + 1];
                }
                inventory[--size] = null;
                return;
            }
        }
        System.out.println("Product not found.");
    }

    public Product getProduct(String productId) {
        for (int i = 0; i < size; i++) {
            if (inventory[i].getProductId().equals(productId)) {
                return inventory[i];
            }
        }
        return null;
    }

    public void displayInventory() {
        if (size == 0) {
            System.out.println("No products in the inventory.");
        } else {
            for (int i = 0; i < size; i++) {
                System.out.println(inventory[i]);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InventoryManager manager = new InventoryManager(100); // Initialize with a capacity of 100

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display Inventory");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    String productId = scanner.nextLine();
                    System.out.print("Enter Product Name: ");
                    String productName = scanner.nextLine();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    Product product = new Product(productId, productName, quantity, price);
                    manager.addProduct(product);
                    break;

                case 2:
                    System.out.print("Enter Product ID to update: ");
                    String updateProductId = scanner.nextLine();
                    System.out.print("Enter New Product Name: ");
                    String newProductName = scanner.nextLine();
                    System.out.print("Enter New Quantity: ");
                    int newQuantity = scanner.nextInt();
                    System.out.print("Enter New Price: ");
                    double newPrice = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    Product newProductData = new Product(updateProductId, newProductName, newQuantity, newPrice);
                    manager.updateProduct(updateProductId, newProductData);
                    break;

                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    String deleteProductId = scanner.nextLine();
                    manager.deleteProduct(deleteProductId);
                    break;

                case 4:
                    System.out.println("Current Inventory:");
                    manager.displayInventory();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
